import React, { useContext } from 'react';
import { OrderContext } from '../context/OrderContext';
import '../styles/OrderForm.css';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as yup from 'yup';

const validationSchema = yup.object({
    orderName: yup.string().required('Order name is required'),
    price: yup.number().required('Price is required').positive('Price must be positive'),
    promo: yup.boolean(),
});

const OrderForm = () => {
    const { addOrder } = useContext(OrderContext);

    return (
        <Formik
            initialValues={{
                orderName: '',
                price: '',
                promo: false,
            }}
            validationSchema={validationSchema}
            onSubmit={(values, { resetForm }) => {
                addOrder(values);
                resetForm();
            }}
        >
            <Form className="order-form">
                <div className="segment">
                    <div className="thead">Order Item</div>
                    <div className="tbody">
                        <Field
                            type="text"
                            name="orderName"
                            placeholder="Order Name"
                            required
                        />
                        <ErrorMessage name="orderName" component="div" className="error" />
                    </div>
                </div>
                <div className="segment">
                    <div className="thead">Price</div>
                    <div className="tbody">
                        <Field
                            type="number"
                            name="price"
                            placeholder="Price"
                            required
                        />
                        <ErrorMessage name="price" component="div" className="error" />
                    </div>
                </div>
                <div className="segment">
                    <div className="thead">On 5% Promo?</div>
                    <div className="tbody">
                        <Field
                            type="checkbox"
                            name="promo"
                        />
                    </div>
                </div>
                <div className="segment">
                    <div className="thead">Action</div>
                    <div className="tbody">
                        <button type="submit">Place Order</button>
                    </div>
                </div>
            </Form>
        </Formik>
    );
};

export default OrderForm;