import React from 'react';
import { Provider } from 'react-redux';
import store from './redux/store';
import OrderProvider from './context/OrderContext';
import Header from './components/Header.jsx';
import DiscountMessage from './components/DiscountMessage.jsx';
import OrderForm from './components/OrderForm.jsx';
import OrderList from './components/OrderList.jsx';
import SideMenu from './components/SideMenu.jsx';
import withErrorBoundary from './hoc/withErrorBoundary';
import './styles/App.css';

const App = () => (
  <Provider store={store}>
    <OrderProvider>
      <Header />
      <DiscountMessage />
      <main className="main">
        <SideMenu />
        <OrderForm />
        <OrderList />
      </main>
    </OrderProvider>
  </Provider>
);

export default withErrorBoundary(App);