import React from 'react';
import '../styles/SideMenu.css';

const SideMenu = () => (
    <section className="side-menu">
        {/* Left Sidebar with Menu Image */}
        <img src="images/menu.jpg" alt="Drinks Menu" className="menu-image" />
    </section>
);

export default SideMenu;