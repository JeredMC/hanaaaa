import React from 'react';
import '../styles/DiscountMessage.css';

const DiscountMessage = () => (
    <div className="discount-message-wrapper">
        <div className="discount-message">
            5% discount on all espresso bar drinks!!! Buy now!
        </div>
    </div>
);

export default DiscountMessage;