import React, { useContext, useState } from 'react';
import { OrderContext } from '../context/OrderContext';
import '../styles/OrderList.css';
import * as yup from 'yup';

const validationSchema = yup.object({
    orderName: yup.string().required('Order name is required'),
    price: yup.number().required('Price is required').positive('Price must be positive'),
    promo: yup.boolean(),
});

const OrderList = () => {
    const { orders, deleteOrder, updateOrder } = useContext(OrderContext);
    const [editingOrderId, setEditingOrderId] = useState(null);
    const [editForm, setEditForm] = useState({ orderName: '', price: '', promo: false });
    const [errors, setErrors] = useState({});

    const validate = async () => {
        try {
            await validationSchema.validate(editForm, { abortEarly: false });
            return {};
        } catch (err) {
            const newErrors = {};
            err.inner.forEach((error) => {
                newErrors[error.path] = error.message;
            });
            return newErrors;
        }
    };

    const handleEdit = (order) => {
        setEditingOrderId(order.id);
        setEditForm({ orderName: order.orderName, price: order.price, promo: order.isDiscounted });
    };

    const handleCancel = () => {
        setEditingOrderId(null);
        setEditForm({ orderName: '', price: '', promo: false });
        setErrors({});
    };

    const handleChange = (e) => {
        const { name, value, checked, type } = e.target;
        setEditForm((prevForm) => ({
            ...prevForm,
            [name]: type === 'checkbox' ? checked : value,
        }));
    };

    const handleSubmit = async (order) => {
        const newErrors = await validate();
        if (Object.keys(newErrors).length > 0) {
            setErrors(newErrors);
        } else {
            updateOrder({ ...order, ...editForm, isDiscounted: editForm.promo });
            handleCancel();
        }
    };

    const totalRegularBill = orders.reduce((total, order) => total + parseFloat(order.price), 0);
    const totalDiscountedBill = orders.reduce(
        (total, order) => total + (order.isDiscounted ? parseFloat(order.price) * 0.95 : parseFloat(order.price)),
        0
    );

    return (
        <div>
            <table className="order-list">
                <thead>
                    <tr>
                        <th>Order Name</th>
                        <th>Price</th>
                        <th>Promo</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {orders.map((order) => (
                        editingOrderId === order.id ? (
                            <tr key={order.id}>
                                <td>
                                    <input
                                        type="text"
                                        name="orderName"
                                        value={editForm.orderName}
                                        onChange={handleChange}
                                    />
                                    {errors.orderName && <div className="error">{errors.orderName}</div>}
                                </td>
                                <td>
                                    <input
                                        type="number"
                                        name="price"
                                        value={editForm.price}
                                        onChange={handleChange}
                                    />
                                    {errors.price && <div className="error">{errors.price}</div>}
                                </td>
                                <td>
                                    <input
                                        type="checkbox"
                                        name="promo"
                                        checked={editForm.promo}
                                        onChange={handleChange}
                                    />
                                </td>
                                <td>
                                    <button type="button" onClick={() => handleSubmit(order)}>Change</button>
                                    <button type="button" onClick={handleCancel}>Cancel</button>
                                </td>
                            </tr>
                        ) : (
                            <tr key={order.id}>
                                <td>{order.orderName}</td>
                                <td>{order.price}</td>
                                <td>{order.isDiscounted ? 'Yes' : 'No'}</td>
                                <td>
                                    <button className="edit" onClick={() => handleEdit(order)}>Edit</button>
                                    <button className="delete" onClick={() => deleteOrder(order.id)}>Delete</button>
                                </td>
                            </tr>
                        )
                    ))}
                    <tr>
                        <td colSpan="4">Total regular bill: ${totalRegularBill.toFixed(2)}</td>
                    </tr>
                    <tr>
                        <td colSpan="4">Total discounted bill: ${totalDiscountedBill.toFixed(2)}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    );
};

export default OrderList;